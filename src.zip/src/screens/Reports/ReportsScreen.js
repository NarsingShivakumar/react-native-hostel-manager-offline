import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { database } from '../../database';
import { Q } from '@nozbe/watermelondb';
import {
  format,
  startOfMonth,
  endOfMonth,
  startOfWeek,
  endOfWeek,
  startOfDay,
  endOfDay,
} from 'date-fns';

export default function ReportsScreen({ navigation }) {
  const [stats, setStats] = useState({
    todayCollection: 0,
    weeklyCollection: 0,
    monthlyCollection: 0,
    totalPending: 0,
    totalGuests: 0,
    activeGuests: 0,
    overdueGuests: 0,
  });
  
  useEffect(() => {
    loadStats();
    
    const subscription = database.get('payments').query().observe().subscribe(() => {
      loadStats();
    });
    
    return () => subscription.unsubscribe();
  }, []);
  
  const loadStats = async () => {
    try {
      const guests = await database.get('guests').query().fetch();
      const payments = await database.get('payments').query().fetch();
      
      const activeGuests = guests.filter(g => g.isActive);
      const overdueGuests = activeGuests.filter(g => g.isPaymentOverdue);
      
      const now = Date.now();
      const todayStart = startOfDay(new Date()).getTime();
      const todayEnd = endOfDay(new Date()).getTime();
      const weekStart = startOfWeek(new Date()).getTime();
      const weekEnd = endOfWeek(new Date()).getTime();
      const monthStart = startOfMonth(new Date()).getTime();
      const monthEnd = endOfMonth(new Date()).getTime();
      
      const todayPayments = payments.filter(
        p => p.status === 'paid' && p.paymentDate >= todayStart && p.paymentDate <= todayEnd
      );
      
      const weeklyPayments = payments.filter(
        p => p.status === 'paid' && p.paymentDate >= weekStart && p.paymentDate <= weekEnd
      );
      
      const monthlyPayments = payments.filter(
        p => p.status === 'paid' && p.paymentDate >= monthStart && p.paymentDate <= monthEnd
      );
      
      const todayCollection = todayPayments.reduce((sum, p) => sum + p.amount, 0);
      const weeklyCollection = weeklyPayments.reduce((sum, p) => sum + p.amount, 0);
      const monthlyCollection = monthlyPayments.reduce((sum, p) => sum + p.amount, 0);
      const totalPending = overdueGuests.reduce((sum, g) => sum + g.paymentAmount, 0);
      
      setStats({
        todayCollection,
        weeklyCollection,
        monthlyCollection,
        totalPending,
        totalGuests: guests.length,
        activeGuests: activeGuests.length,
        overdueGuests: overdueGuests.length,
      });
    } catch (error) {
      console.error('Error loading stats:', error);
    }
  };
  
  return (
    <ScrollView style={styles.container}>
      {/* Collection Report */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Collection Report</Text>
        
        <ReportCard
          icon="calendar-today"
          label="Today's Collection"
          value={`₹${stats.todayCollection.toLocaleString()}`}
          color="#2196f3"
        />
        
        <ReportCard
          icon="calendar-week"
          label="This Week"
          value={`₹${stats.weeklyCollection.toLocaleString()}`}
          color="#00bcd4"
        />
        
        <ReportCard
          icon="calendar-month"
          label="This Month"
          value={`₹${stats.monthlyCollection.toLocaleString()}`}
          color="#4caf50"
        />
      </View>
      
      {/* Guest Statistics */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Guest Statistics</Text>
        
        <View style={styles.statsGrid}>
          <StatBox
            icon="account-group"
            label="Total Guests"
            value={stats.totalGuests}
            color="#9c27b0"
          />
          
          <StatBox
            icon="account-check"
            label="Active"
            value={stats.activeGuests}
            color="#4caf50"
          />
          
          <StatBox
            icon="alert-circle"
            label="Overdue"
            value={stats.overdueGuests}
            color="#f44336"
          />
          
          <StatBox
            icon="cash-clock"
            label="Pending"
            value={`₹${stats.totalPending.toLocaleString()}`}
            color="#ff9800"
            small
          />
        </View>
      </View>
      
      {/* Quick Actions */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Export & Backup</Text>
        
        <TouchableOpacity
          style={styles.actionCard}
          onPress={() => navigation.navigate('ExportImport')}
        >
          <View style={styles.actionLeft}>
            <Icon name="file-export" size={32} color="#6200ee" />
            <View style={styles.actionContent}>
              <Text style={styles.actionTitle}>Export Data</Text>
              <Text style={styles.actionSubtitle}>
                Export all data to CSV or JSON
              </Text>
            </View>
          </View>
          <Icon name="chevron-right" size={24} color="#999" />
        </TouchableOpacity>
        
        <TouchableOpacity
          style={styles.actionCard}
          onPress={() => navigation.navigate('ExportImport')}
        >
          <View style={styles.actionLeft}>
            <Icon name="file-import" size={32} color="#6200ee" />
            <View style={styles.actionContent}>
              <Text style={styles.actionTitle}>Import Data</Text>
              <Text style={styles.actionSubtitle}>
                Restore data from backup file
              </Text>
            </View>
          </View>
          <Icon name="chevron-right" size={24} color="#999" />
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const ReportCard = ({ icon, label, value, color }) => (
  <View style={styles.reportCard}>
    <View style={[styles.reportIcon, { backgroundColor: color }]}>
      <Icon name={icon} size={28} color="#fff" />
    </View>
    <View style={styles.reportContent}>
      <Text style={styles.reportLabel}>{label}</Text>
      <Text style={styles.reportValue}>{value}</Text>
    </View>
  </View>
);

const StatBox = ({ icon, label, value, color, small }) => (
  <View style={styles.statBox}>
    <Icon name={icon} size={32} color={color} />
    <Text style={[styles.statValue, small && { fontSize: 16 }]}>{value}</Text>
    <Text style={styles.statLabel}>{label}</Text>
  </View>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  section: {
    backgroundColor: '#fff',
    marginTop: 8,
    padding: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 16,
  },
  reportCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f9f9f9',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
  },
  reportIcon: {
    width: 56,
    height: 56,
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
  },
  reportContent: {
    marginLeft: 16,
    flex: 1,
  },
  reportLabel: {
    fontSize: 14,
    color: '#666',
  },
  reportValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    marginTop: 4,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  statBox: {
    width: '48%',
    backgroundColor: '#f9f9f9',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    marginTop: 8,
  },
  statLabel: {
    fontSize: 12,
    color: '#666',
    marginTop: 4,
    textAlign: 'center',
  },
  actionCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#f9f9f9',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
  },
  actionLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  actionContent: {
    marginLeft: 16,
    flex: 1,
  },
  actionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  actionSubtitle: {
    fontSize: 13,
    color: '#999',
    marginTop: 2,
  },
});
