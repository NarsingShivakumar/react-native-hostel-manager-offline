import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  TouchableOpacity,
  Alert,
  Platform,
  Image,
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { launchImageLibrary } from 'react-native-image-picker';
import { database } from '../../database';
import { addDays, addWeeks, addMonths } from 'date-fns';
import NotificationService from '../../services/NotificationService';

export default function AddGuestScreen({ navigation }) {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    age: '',
    gender: 'Male',
    mobileNumber: '',
    email: '',
    aadharNumber: '',
    photoUri: '',
    roomNumber: '',
    bedNumber: '',
    paymentType: 'monthly',
    paymentAmount: '',
    guardianName: '',
    guardianRelationship: '',
    guardianMobile: '',
    guardianAddress: '',
  });
  
  const [loading, setLoading] = useState(false);
  
  const updateField = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };
  
  const selectPhoto = () => {
    launchImageLibrary(
      {
        mediaType: 'photo',
        quality: 0.7,
      },
      response => {
        if (!response.didCancel && !response.error) {
          updateField('photoUri', response.assets[0].uri);
        }
      }
    );
  };
  
  const calculateDueDate = (paymentType) => {
    const today = new Date();
    switch (paymentType) {
      case 'daily':
        return addDays(today, 1);
      case 'weekly':
        return addWeeks(today, 1);
      case 'monthly':
      default:
        return addMonths(today, 1);
    }
  };
  
  const validateForm = () => {
    if (!formData.firstName.trim()) {
      Alert.alert('Error', 'Please enter first name');
      return false;
    }
    if (!formData.lastName.trim()) {
      Alert.alert('Error', 'Please enter last name');
      return false;
    }
    if (!formData.age || parseInt(formData.age) < 1) {
      Alert.alert('Error', 'Please enter valid age');
      return false;
    }
    if (!formData.mobileNumber || formData.mobileNumber.length !== 10) {
      Alert.alert('Error', 'Please enter valid 10-digit mobile number');
      return false;
    }
    if (!formData.aadharNumber || formData.aadharNumber.length !== 12) {
      Alert.alert('Error', 'Please enter valid 12-digit Aadhar number');
      return false;
    }
    if (!formData.roomNumber.trim()) {
      Alert.alert('Error', 'Please enter room number');
      return false;
    }
    if (!formData.paymentAmount || parseFloat(formData.paymentAmount) <= 0) {
      Alert.alert('Error', 'Please enter valid payment amount');
      return false;
    }
    return true;
  };
  
  const handleSubmit = async () => {
    if (!validateForm()) return;
    
    setLoading(true);
    try {
      const dueDate = calculateDueDate(formData.paymentType);
      
      await database.write(async () => {
        // Create guest
        const guest = await database.get('guests').create(newGuest => {
          newGuest.firstName = formData.firstName.trim();
          newGuest.lastName = formData.lastName.trim();
          newGuest.age = parseInt(formData.age);
          newGuest.gender = formData.gender;
          newGuest.mobileNumber = formData.mobileNumber;
          newGuest.email = formData.email.trim();
          newGuest.aadharNumber = formData.aadharNumber;
          newGuest.photoUri = formData.photoUri;
          newGuest.roomNumber = formData.roomNumber.trim();
          newGuest.bedNumber = formData.bedNumber.trim();
          newGuest.paymentType = formData.paymentType;
          newGuest.paymentAmount = parseFloat(formData.paymentAmount);
          newGuest.paymentDueDate = dueDate;
          newGuest.joinDate = new Date();
          newGuest.isActive = true;
        });
        
        // Create guardian if provided
        if (formData.guardianName && formData.guardianMobile) {
          await database.get('guardians').create(guardian => {
            guardian.guestId = guest.id;
            guardian.name = formData.guardianName.trim();
            guardian.relationship = formData.guardianRelationship.trim();
            guardian.mobileNumber = formData.guardianMobile;
            guardian.address = formData.guardianAddress.trim();
          });
        }
        
        // Schedule payment reminders
        await NotificationService.schedulePaymentReminder(guest, 3);
        await NotificationService.scheduleOverdueNotification(guest);
      });
      
      Alert.alert('Success', 'Guest added successfully', [
        { text: 'OK', onPress: () => navigation.goBack() },
      ]);
    } catch (error) {
      console.error('Error adding guest:', error);
      Alert.alert('Error', 'Failed to add guest. Please try again.');
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <ScrollView style={styles.container}>
      <View style={styles.form}>
        {/* Photo Section */}
        <View style={styles.photoSection}>
          <TouchableOpacity onPress={selectPhoto} style={styles.photoButton}>
            {formData.photoUri ? (
              <Image source={{ uri: formData.photoUri }} style={styles.photo} />
            ) : (
              <View style={styles.photoPlaceholder}>
                <Icon name="camera" size={40} color="#999" />
                <Text style={styles.photoText}>Add Photo</Text>
              </View>
            )}
          </TouchableOpacity>
        </View>
        
        {/* Personal Details */}
        <Text style={styles.sectionTitle}>Personal Details</Text>
        
        <View style={styles.row}>
          <View style={styles.halfWidth}>
            <Text style={styles.label}>First Name *</Text>
            <TextInput
              style={styles.input}
              value={formData.firstName}
              onChangeText={text => updateField('firstName', text)}
              placeholder="Enter first name"
            />
          </View>
          
          <View style={styles.halfWidth}>
            <Text style={styles.label}>Last Name *</Text>
            <TextInput
              style={styles.input}
              value={formData.lastName}
              onChangeText={text => updateField('lastName', text)}
              placeholder="Enter last name"
            />
          </View>
        </View>
        
        <View style={styles.row}>
          <View style={styles.halfWidth}>
            <Text style={styles.label}>Age *</Text>
            <TextInput
              style={styles.input}
              value={formData.age}
              onChangeText={text => updateField('age', text)}
              placeholder="Enter age"
              keyboardType="number-pad"
            />
          </View>
          
          <View style={styles.halfWidth}>
            <Text style={styles.label}>Gender *</Text>
            <View style={styles.genderContainer}>
              <TouchableOpacity
                style={[
                  styles.genderButton,
                  formData.gender === 'Male' && styles.genderButtonActive,
                ]}
                onPress={() => updateField('gender', 'Male')}
              >
                <Text
                  style={[
                    styles.genderText,
                    formData.gender === 'Male' && styles.genderTextActive,
                  ]}
                >
                  Male
                </Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={[
                  styles.genderButton,
                  formData.gender === 'Female' && styles.genderButtonActive,
                ]}
                onPress={() => updateField('gender', 'Female')}
              >
                <Text
                  style={[
                    styles.genderText,
                    formData.gender === 'Female' && styles.genderTextActive,
                  ]}
                >
                  Female
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
        
        <Text style={styles.label}>Mobile Number *</Text>
        <TextInput
          style={styles.input}
          value={formData.mobileNumber}
          onChangeText={text => updateField('mobileNumber', text)}
          placeholder="10-digit mobile number"
          keyboardType="phone-pad"
          maxLength={10}
        />
        
        <Text style={styles.label}>Email</Text>
        <TextInput
          style={styles.input}
          value={formData.email}
          onChangeText={text => updateField('email', text)}
          placeholder="Enter email address"
          keyboardType="email-address"
          autoCapitalize="none"
        />
        
        <Text style={styles.label}>Aadhar Number *</Text>
        <TextInput
          style={styles.input}
          value={formData.aadharNumber}
          onChangeText={text => updateField('aadharNumber', text)}
          placeholder="12-digit Aadhar number"
          keyboardType="number-pad"
          maxLength={12}
        />
        
        {/* Room Details */}
        <Text style={styles.sectionTitle}>Room Details</Text>
        
        <View style={styles.row}>
          <View style={styles.halfWidth}>
            <Text style={styles.label}>Room Number *</Text>
            <TextInput
              style={styles.input}
              value={formData.roomNumber}
              onChangeText={text => updateField('roomNumber', text)}
              placeholder="Room no."
            />
          </View>
          
          <View style={styles.halfWidth}>
            <Text style={styles.label}>Bed Number</Text>
            <TextInput
              style={styles.input}
              value={formData.bedNumber}
              onChangeText={text => updateField('bedNumber', text)}
              placeholder="Bed no."
            />
          </View>
        </View>
        
        {/* Payment Details */}
        <Text style={styles.sectionTitle}>Payment Details</Text>
        
        <Text style={styles.label}>Payment Type *</Text>
        <View style={styles.paymentTypeContainer}>
          {['daily', 'weekly', 'monthly'].map(type => (
            <TouchableOpacity
              key={type}
              style={[
                styles.paymentTypeButton,
                formData.paymentType === type && styles.paymentTypeButtonActive,
              ]}
              onPress={() => updateField('paymentType', type)}
            >
              <Text
                style={[
                  styles.paymentTypeText,
                  formData.paymentType === type && styles.paymentTypeTextActive,
                ]}
              >
                {type.charAt(0).toUpperCase() + type.slice(1)}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
        
        <Text style={styles.label}>Payment Amount *</Text>
        <TextInput
          style={styles.input}
          value={formData.paymentAmount}
          onChangeText={text => updateField('paymentAmount', text)}
          placeholder="Enter amount"
          keyboardType="decimal-pad"
        />
        
        {/* Guardian Details */}
        <Text style={styles.sectionTitle}>Guardian Details (Optional)</Text>
        
        <Text style={styles.label}>Guardian Name</Text>
        <TextInput
          style={styles.input}
          value={formData.guardianName}
          onChangeText={text => updateField('guardianName', text)}
          placeholder="Enter guardian name"
        />
        
        <View style={styles.row}>
          <View style={styles.halfWidth}>
            <Text style={styles.label}>Relationship</Text>
            <TextInput
              style={styles.input}
              value={formData.guardianRelationship}
              onChangeText={text => updateField('guardianRelationship', text)}
              placeholder="e.g., Father"
            />
          </View>
          
          <View style={styles.halfWidth}>
            <Text style={styles.label}>Mobile Number</Text>
            <TextInput
              style={styles.input}
              value={formData.guardianMobile}
              onChangeText={text => updateField('guardianMobile', text)}
              placeholder="10-digit number"
              keyboardType="phone-pad"
              maxLength={10}
            />
          </View>
        </View>
        
        <Text style={styles.label}>Guardian Address</Text>
        <TextInput
          style={[styles.input, styles.textArea]}
          value={formData.guardianAddress}
          onChangeText={text => updateField('guardianAddress', text)}
          placeholder="Enter address"
          multiline
          numberOfLines={3}
        />
        
        {/* Submit Button */}
        <TouchableOpacity
          style={[styles.submitButton, loading && styles.submitButtonDisabled]}
          onPress={handleSubmit}
          disabled={loading}
        >
          <Text style={styles.submitButtonText}>
            {loading ? 'Adding Guest...' : 'Add Guest'}
          </Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  form: {
    padding: 16,
  },
  photoSection: {
    alignItems: 'center',
    marginBottom: 24,
  },
  photoButton: {
    width: 120,
    height: 120,
    borderRadius: 60,
    overflow: 'hidden',
  },
  photo: {
    width: '100%',
    height: '100%',
  },
  photoPlaceholder: {
    width: '100%',
    height: '100%',
    backgroundColor: '#f0f0f0',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#ddd',
    borderStyle: 'dashed',
  },
  photoText: {
    marginTop: 8,
    color: '#999',
    fontSize: 14,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginTop: 24,
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    color: '#666',
    marginBottom: 8,
  },
  input: {
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 16,
    marginBottom: 16,
  },
  textArea: {
    height: 80,
    textAlignVertical: 'top',
  },
  row: {
    flexDirection: 'row',
    gap: 12,
  },
  halfWidth: {
    flex: 1,
  },
  genderContainer: {
    flexDirection: 'row',
    gap: 8,
  },
  genderButton: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#ddd',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  genderButtonActive: {
    backgroundColor: '#6200ee',
    borderColor: '#6200ee',
  },
  genderText: {
    fontSize: 16,
    color: '#666',
  },
  genderTextActive: {
    color: '#fff',
    fontWeight: '600',
  },
  paymentTypeContainer: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 16,
  },
  paymentTypeButton: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#ddd',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  paymentTypeButtonActive: {
    backgroundColor: '#6200ee',
    borderColor: '#6200ee',
  },
  paymentTypeText: {
    fontSize: 14,
    color: '#666',
  },
  paymentTypeTextActive: {
    color: '#fff',
    fontWeight: '600',
  },
  submitButton: {
    backgroundColor: '#6200ee',
    paddingVertical: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 24,
    marginBottom: 32,
  },
  submitButtonDisabled: {
    opacity: 0.6,
  },
  submitButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
});
